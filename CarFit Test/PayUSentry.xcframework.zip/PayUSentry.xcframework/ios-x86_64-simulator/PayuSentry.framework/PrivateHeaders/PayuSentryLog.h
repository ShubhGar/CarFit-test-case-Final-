#import <Foundation/Foundation.h>

#import "PayuSentryDefines.h"

NS_ASSUME_NONNULL_BEGIN

@interface PayuSentryLog : NSObject

+ (void)logWithMessage:(NSString *)message andLevel:(SentryLogLevel)level;

@end

NS_ASSUME_NONNULL_END
