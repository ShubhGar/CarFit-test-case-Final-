#import <Foundation/Foundation.h>

#import "PayuSentryCrash.h"

@interface PayuSentryCrashReportSink : NSObject <PayuSentryCrashReportFilter>

@end
