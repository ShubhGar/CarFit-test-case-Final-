#import <Foundation/Foundation.h>

#import "PayuSentryCrash.h"
#import "PayuSentryCrashInstallation.h"

@interface PayuSentryCrashInstallationReporter : PayuSentryCrashInstallation

- (void)sendAllReports;

@end
