#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSData (PayuSentryCompression)

- (NSData *_Nullable)payuSentry_gzippedWithCompressionLevel:(NSInteger)compressionLevel
                                                  error:(NSError *_Nullable *_Nullable)error;

@end

NS_ASSUME_NONNULL_END
