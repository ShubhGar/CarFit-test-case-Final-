#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDate (PayuSentryExtras)

+ (NSDate *)payuSentry_fromIso8601String:(NSString *)string;

- (NSString *)payuSentry_toIso8601String;

@end

NS_ASSUME_NONNULL_END
