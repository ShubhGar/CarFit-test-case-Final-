#import "PayuSentryDefines.h"
#import "PayuSentrySerializable.h"

NS_ASSUME_NONNULL_BEGIN

@class PayuSentryStacktrace;

NS_SWIFT_NAME(Thread)
@interface PayuSentryThread : NSObject <PayuSentrySerializable>
SENTRY_NO_INIT

/**
 * Number of the thread
 */
@property (nonatomic, copy) NSNumber *threadId;

/**
 * Name (if available) of the thread
 */
@property (nonatomic, copy) NSString *_Nullable name;

/**
 * PayuSentryStacktrace of the PayuSentryThread
 */
@property (nonatomic, strong) PayuSentryStacktrace *_Nullable stacktrace;

/**
 * Did this thread crash?
 */
@property (nonatomic, copy) NSNumber *_Nullable crashed;

/**
 * Was it the current thread.
 */
@property (nonatomic, copy) NSNumber *_Nullable current;

/**
 * Initializes a PayuSentryThread with its id
 * @param threadId NSNumber
 * @return PayuSentryThread
 */
- (instancetype)initWithThreadId:(NSNumber *)threadId;

@end

NS_ASSUME_NONNULL_END
