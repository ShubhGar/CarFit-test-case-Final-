#import "PayuSentryDefines.h"
#import "PayuSentrySerializable.h"

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(User)
@interface PayuSentryUser : NSObject <PayuSentrySerializable, NSCopying>

/**
 * Optional: Id of the user
 */
@property (nonatomic, copy) NSString *userId;

/**
 * Optional: Email of the user
 */
@property (nonatomic, copy) NSString *_Nullable email;

/**
 * Optional: Username
 */
@property (nonatomic, copy) NSString *_Nullable username;

/**
 * Optional: IP Address
 */
@property (nonatomic, copy) NSString *_Nullable ipAddress;

/**
 * Optional: Additional data
 */
@property (nonatomic, strong) NSDictionary<NSString *, id> *_Nullable data;

/**
 * Initializes a PayuSentryUser with the id
 * @param userId NSString
 * @return PayuSentryUser
 */
- (instancetype)initWithUserId:(NSString *)userId;

- (instancetype)init;
+ (instancetype)new NS_UNAVAILABLE;

- (BOOL)isEqual:(id _Nullable)other;

- (BOOL)isEqualToUser:(PayuSentryUser *)user;

- (NSUInteger)hash;

@end

NS_ASSUME_NONNULL_END
