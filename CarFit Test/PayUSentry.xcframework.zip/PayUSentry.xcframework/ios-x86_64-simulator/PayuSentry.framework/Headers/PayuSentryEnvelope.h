#import <Foundation/Foundation.h>

#import "PayuSentryDefines.h"

@class PayuSentryEvent, PayuSentrySession, PayuSentrySdkInfo, PayuSentryId, PayuSentryUserFeedback;

NS_ASSUME_NONNULL_BEGIN

@interface PayuSentryEnvelopeHeader : NSObject
SENTRY_NO_INIT

/**
 * Initializes an PayuSentryEnvelopeHeader object with the specified eventId.
 *
 * Sets the sdkInfo from PayuSentryMeta.
 *
 * @param eventId The identifier of the event. Can be nil if no event in the envelope or attachment
 * related to event.
 */
- (instancetype)initWithId:(PayuSentryId *_Nullable)eventId;

/**
 * Initializes an PayuSentryEnvelopeHeader object with the specified eventId and skdInfo.
 *
 * It is recommended to use initWithId:eventId: because it sets the sdkInfo for you.
 *
 * @param eventId The identifier of the event. Can be nil if no event in the envelope or attachment
 * related to event.
 * @param sdkInfo sdkInfo Describes the Sentry SDK. Can be nil for backwards compatibility. New
 * instances should always provide a version.
 */
- (instancetype)initWithId:(PayuSentryId *_Nullable)eventId
                andSdkInfo:(PayuSentrySdkInfo *_Nullable)sdkInfo NS_DESIGNATED_INITIALIZER;

/**
 * The event identifier, if available.
 * An event id exist if the envelope contains an event of items within it are
 * related. i.e Attachments
 */
@property (nonatomic, readonly, copy) PayuSentryId *_Nullable eventId;

@property (nonatomic, readonly, copy) PayuSentrySdkInfo *_Nullable sdkInfo;

@end

@interface PayuSentryEnvelopeItemHeader : NSObject
SENTRY_NO_INIT

- (instancetype)initWithType:(NSString *)type length:(NSUInteger)length NS_DESIGNATED_INITIALIZER;

/**
 * The type of the envelope item.
 */
@property (nonatomic, readonly, copy) NSString *type;
@property (nonatomic, readonly) NSUInteger length;

@end

@interface PayuSentryEnvelopeItem : NSObject
SENTRY_NO_INIT

- (instancetype)initWithEvent:(PayuSentryEvent *)event;
- (instancetype)initWithSession:(PayuSentrySession *)session;
- (instancetype)initWithUserFeedback:(PayuSentryUserFeedback *)userFeedback;
- (instancetype)initWithHeader:(PayuSentryEnvelopeItemHeader *)header
                          data:(NSData *)data NS_DESIGNATED_INITIALIZER;

/**
 * The envelope item header.
 */
@property (nonatomic, readonly, strong) PayuSentryEnvelopeItemHeader *header;

/**
 * The envelope payload.
 */
@property (nonatomic, readonly, strong) NSData *data;

@end

@interface PayuSentryEnvelope : NSObject
SENTRY_NO_INIT

// If no event, or no data related to event, id will be null
- (instancetype)initWithId:(PayuSentryId *_Nullable)id singleItem:(PayuSentryEnvelopeItem *)item;

- (instancetype)initWithHeader:(PayuSentryEnvelopeHeader *)header singleItem:(PayuSentryEnvelopeItem *)item;

// If no event, or no data related to event, id will be null
- (instancetype)initWithId:(PayuSentryId *_Nullable)id items:(NSArray<PayuSentryEnvelopeItem *> *)items;

/**
 * Initializes a PayuSentryEnvelope with a single session.
 * @param session to init the envelope with.
 * @return an initialized PayuSentryEnvelope
 */
- (instancetype)initWithSession:(PayuSentrySession *)session;

/**
 * Initializes a PayuSentryEnvelope with a list of sessions.
 * Can be used when an operations that starts a session closes an ongoing
 * session
 * @param sessions to init the envelope with.
 * @return an initialized PayuSentryEnvelope
 */
- (instancetype)initWithSessions:(NSArray<PayuSentrySession *> *)sessions;

- (instancetype)initWithHeader:(PayuSentryEnvelopeHeader *)header
                         items:(NSArray<PayuSentryEnvelopeItem *> *)items NS_DESIGNATED_INITIALIZER;

// Convenience init for a single event
- (instancetype)initWithEvent:(PayuSentryEvent *)event;

- (instancetype)initWithUserFeedback:(PayuSentryUserFeedback *)userFeedback;

/**
 * The envelope header.
 */
@property (nonatomic, readonly, strong) PayuSentryEnvelopeHeader *header;

/**
 * The envelope items.
 */
@property (nonatomic, readonly, strong) NSArray<PayuSentryEnvelopeItem *> *items;

@end

NS_ASSUME_NONNULL_END
