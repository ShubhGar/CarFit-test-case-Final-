#import <Foundation/Foundation.h>

#import "PayuSentryDefines.h"
#import "PayuSentrySerializable.h"

NS_ASSUME_NONNULL_BEGIN

@class PayuSentryFrame;

NS_SWIFT_NAME(Stacktrace)
@interface PayuSentryStacktrace : NSObject <PayuSentrySerializable>
SENTRY_NO_INIT

/**
 * Array of all PayuSentryFrame in the stacktrace
 */
@property (nonatomic, strong) NSArray<PayuSentryFrame *> *frames;

/**
 * Registers of the thread for additional information used on the server
 */
@property (nonatomic, strong) NSDictionary<NSString *, NSString *> *registers;

/**
 * Initialize a PayuSentryStacktrace with frames and registers
 * @param frames NSArray
 * @param registers NSArray
 * @return PayuSentryStacktrace
 */
- (instancetype)initWithFrames:(NSArray<PayuSentryFrame *> *)frames
                     registers:(NSDictionary<NSString *, NSString *> *)registers;

/**
 * This will be called internally, is used to remove duplicated frames for
 * certain crashes.
 */
- (void)fixDuplicateFrames;

@end

NS_ASSUME_NONNULL_END
