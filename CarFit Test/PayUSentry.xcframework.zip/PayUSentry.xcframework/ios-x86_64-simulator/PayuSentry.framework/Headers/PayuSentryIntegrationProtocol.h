#import <Foundation/Foundation.h>

#import "PayuSentryDefines.h"
#import "PayuSentryOptions.h"

NS_ASSUME_NONNULL_BEGIN

@protocol PayuSentryIntegrationProtocol <NSObject>

/**
 * installs the integration and returns YES if successful.
 */
- (void)installWithOptions:(PayuSentryOptions *)options;

@end

NS_ASSUME_NONNULL_END
